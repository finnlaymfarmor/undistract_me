# undistract_me
Browser extension that renders social media sites black and white, lowering your dopamine

Download all the files (zip file to be provided soon on a download link)
Put them in a file (called it whatever you would like)
Drag file into your extensions in any chromium browser (ensure you have developer mode enabled)
This will make all social media sites listed black and white

List = Facebook, Reddit, Instagram, Twitter, TikTok

For any suggestions or other websites, please email me:

finnlaym@farmorsoftware.com

Ta!



For reference, here is an article detailing the positive effects of making your phone screen black and white:
https://metro.co.uk/2019/04/12/making-iphone-display-black-white-boost-happiness-wellbeing-9181828/

The concept has simply been adopted for laptops. I don't think everything black and white is necessary for laptops, just your social media sites. Enjoy!
